Compile main.tex with pdfLaTeX until references stabilize (2-4 passes).
All figure PDFs are included.
Uses acmart [sigplan,10pt,review] and ACM-Reference-Format.
main.bbl is included; BibTeX is needed only to regenerate references.
No Python, system fonts, shell escape, or Biber required.
The compiled article is deliberately excluded from this source archive.
data/results.json records evidence provenance and numerical summaries.
