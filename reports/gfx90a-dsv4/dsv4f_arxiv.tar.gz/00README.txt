Compile main.tex with pdfLaTeX until references stabilize (2-4 passes).
All figure PDFs are included.
No Python, system fonts, shell escape, BibTeX, or Biber required.
The compiled article is deliberately excluded from this source archive.
data/results.json records evidence provenance and numerical summaries.
