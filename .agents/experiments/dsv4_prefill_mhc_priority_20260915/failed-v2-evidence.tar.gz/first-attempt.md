# First component attempt: harness failure, not a large-M result

Source revision: `efcf1eb71d` (oracle unchanged through `7229ac94b1`).
Command used physical GPU4, sizes1/8192, three mutations and six replays.
Run session57456 exited1. `screen-small.json` is the preserved partial file;
its `status:running` must not be interpreted as an active process or a
completed screen.

M1 completed: A/B/R outputs byte-exact, three mutation checks passed,
A and B each6/6 eager replays exact, row-permutation check passed.
The same-path allocating Python-boundary timings were0.210991/0.212223ms,
not an AR service speed claim.

The next shape M8192 failed during warmup, before any result was accepted:

```
mhc.py:3100: get_tp_group(), disabled=not is_allocation_symmetric()
parallel_state.py:1953:
AssertionError: tensor model parallel group is not initialized
```

The FP32 path evaluates the group accessor even though symmetric allocation
is disabled in this single-GCD test. Existing standalone MHC oracles use a
None group and disabled symmetric allocation for this no-collective boundary.
The retry follows that pattern in every arm and restores the accessors in
`finally`. No production math, dispatcher or service configuration is changed.
No M8192 speed, correctness or replay result follows from this failed attempt.
