from __future__ import annotations

from typing import (
    TYPE_CHECKING,
    Any,
    Callable,
    Dict,
    List,
    Optional,
    Tuple,
    TypeAlias,
    Union,
)

import os

_prefill_detail_mark = None
if os.getenv("SGLANG_DSV4_DEBUG_PREFILL_MARKERS_DIR"):
    from sglang.kernels.ops.debug.dsv4_prefill_markers import detail_mark as _prefill_detail_mark

import torch
import torch.nn as nn
import torch.nn.functional as F

try:
    import triton
    import triton.language as tl
except ImportError:
    triton = None
    tl = None

from sglang.kernels.ops.attention.dsv4 import (
    fused_q_indexer_rope_hadamard_fp4_quant,
    fused_q_indexer_rope_hadamard_quant,
    topk_transform_512,
    topk_transform_512_v2,
)
from sglang.kernels.ops.quantization.fp8_kernel import is_fp8_fnuz
from sglang.srt.configs.deepseek_v4 import DeepSeekV4Config
from sglang.srt.environ import envs
from sglang.srt.layers.attention.dsa.dsa_topk_backend import DSATopKBackend
from sglang.srt.layers.attention.dsa.utils import (
    INDEXER_K_CACHE_PRESHUFFLE_TILE,
    aiter_can_use_preshuffle_paged_mqa,
)
from sglang.srt.layers.attention.dsv4.compressor import Compressor
from sglang.srt.layers.attention.dsv4.metadata import (
    NonPagedIndexerPlan,
    PagedIndexerMetadata,
)
from sglang.srt.layers.linear import ReplicatedLinear
from sglang.srt.model_executor.forward_batch_info import ForwardMode
from sglang.srt.model_executor.runner_backend_utils.breakable_cuda_graph.context import (
    is_in_breakable_cuda_graph,
)
from sglang.srt.model_executor.runner_backend_utils.tc_piecewise_cuda_graph import (
    is_in_tc_piecewise_cuda_graph,
)
from sglang.srt.runtime_context import get_exec, get_parallel
from sglang.srt.state_capturer.indexer_topk import get_global_indexer_capturer
from sglang.srt.utils import add_prefix, is_cuda, is_hip, is_xpu
from sglang.srt.utils.common import is_gfx90a_supported, is_sm120_supported

if TYPE_CHECKING:
    from sglang.srt.layers.attention.base_attn_backend import AttentionBackend
    from sglang.srt.layers.attention.dsv4.compressor import (
        CompressorBackendMixin,
    )
    from sglang.srt.layers.quantization import QuantizationConfig
    from sglang.srt.mem_cache.deepseek_v4_memory_pool import DeepSeekV4TokenToKVPool
    from sglang.srt.model_executor.forward_batch_info import ForwardBatch


FP8_DTYPE = torch.float8_e4m3fnuz if is_fp8_fnuz() else torch.float8_e4m3fn


IndexerQuery: TypeAlias = Union[torch.Tensor, Tuple[torch.Tensor, torch.Tensor]]


_arange_cache = {}
_fp8_paged_mqa_logits_debug_logged = False
_c4_empty_tiles_debug_logged = False
_c4_empty_prefill_debug_logged = False
_c4_query_reuse_debug_logged = False
_c4_query_wide_debug_logged = False
_c4_trivial_logits_debug_logged = False


def _debug_fp8_paged_mqa_logits_skip(reason: str) -> None:
    global _fp8_paged_mqa_logits_debug_logged
    if _fp8_paged_mqa_logits_debug_logged:
        return
    if os.environ.get("SGLANG_DSV4_INDEXER_DEBUG", "0") not in ("1", "true", "True"):
        return
    _fp8_paged_mqa_logits_debug_logged = True
    print(f"[DSV4 indexer] full Triton skip: {reason}", flush=True)


if triton is not None:

    @triton.jit
    def _fp8_mqa_logits_post_kernel(
        scores,
        weights,
        kv_scales,
        seq_lens,
        out,
        padded_seq_len: tl.constexpr,
        max_seq_len: tl.constexpr,
        num_heads: tl.constexpr,
        scores_stride_b: tl.constexpr,
        scores_stride_s: tl.constexpr,
        scores_stride_h: tl.constexpr,
        weights_stride_b: tl.constexpr,
        weights_stride_h: tl.constexpr,
        scales_stride_b: tl.constexpr,
        scales_stride_s: tl.constexpr,
        out_stride_b: tl.constexpr,
        out_stride_s: tl.constexpr,
        BLOCK_S: tl.constexpr,
        BLOCK_H: tl.constexpr,
    ):
        bid = tl.program_id(0)
        block_id = tl.program_id(1)
        offs_s = block_id * BLOCK_S + tl.arange(0, BLOCK_S)
        offs_h = tl.arange(0, BLOCK_H)

        s_mask = offs_s < padded_seq_len
        h_mask = offs_h < num_heads
        vals = tl.load(
            scores
            + bid * scores_stride_b
            + offs_s[:, None] * scores_stride_s
            + offs_h[None, :] * scores_stride_h,
            mask=s_mask[:, None] & h_mask[None, :],
            other=0.0,
        ).to(tl.float32)
        w = tl.load(
            weights + bid * weights_stride_b + offs_h * weights_stride_h,
            mask=h_mask,
            other=0.0,
        ).to(tl.float32)
        reduced = tl.sum(tl.maximum(vals, 0.0) * w[None, :], axis=1)
        scale = tl.load(
            kv_scales + bid * scales_stride_b + offs_s * scales_stride_s,
            mask=s_mask,
            other=0.0,
        ).to(tl.float32)
        seq_len = tl.load(seq_lens + bid)
        result = reduced * scale
        result = tl.where(offs_s < seq_len, result, 0.0)
        tl.store(
            out + bid * out_stride_b + offs_s * out_stride_s,
            result,
            mask=offs_s < max_seq_len,
        )

    @triton.jit
    def _fp8_paged_mqa_logits_kernel(
        q_u8,
        kvcache_u8,
        weights,
        seq_lens,
        page_table,
        out,
        max_num_pages: tl.constexpr,
        max_seq_len: tl.constexpr,
        num_heads: tl.constexpr,
        q_stride_b: tl.constexpr,
        q_stride_h: tl.constexpr,
        q_stride_d: tl.constexpr,
        kv_stride_page: tl.constexpr,
        weights_stride_b: tl.constexpr,
        weights_stride_h: tl.constexpr,
        page_table_stride_b: tl.constexpr,
        page_table_stride_p: tl.constexpr,
        out_stride_b: tl.constexpr,
        out_stride_s: tl.constexpr,
        FP8_TY: tl.constexpr,
        DOT_TY: tl.constexpr,
        PRESHUFFLE_TILE: tl.constexpr,
        BLOCK_S: tl.constexpr,
        BLOCK_H: tl.constexpr,
        BLOCK_D: tl.constexpr,
        TRIVIAL_TOPK: tl.constexpr,
    ):
        bid = tl.program_id(0)
        block_id = tl.program_id(1)

        offs_s = block_id * BLOCK_S + tl.arange(0, BLOCK_S)
        offs_h = tl.arange(0, BLOCK_H)
        offs_d = tl.arange(0, BLOCK_D)

        seq_len = tl.load(seq_lens + bid)
        if TRIVIAL_TOPK == 0 or seq_len > TRIVIAL_TOPK:
            page_offsets = offs_s // 64
            pos_in_page = offs_s - page_offsets * 64
            page_in_range = page_offsets < max_num_pages
            page_ids = tl.load(
                page_table
                + bid * page_table_stride_b
                + page_offsets * page_table_stride_p,
                mask=page_in_range,
                other=-1,
            )
            page_ids = tl.maximum(page_ids, 0)
            valid_s = (offs_s < seq_len) & page_in_range

            page_base = page_ids * kv_stride_page
            if PRESHUFFLE_TILE:
                # Match triton_fused_store_indexer: token-tile, column-tile,
                # token-within-tile, column-within-tile. A linear read would
                # consume other (possibly unwritten) tokens in a partial page.
                kv_offsets = (page_base[:, None]
                    + (pos_in_page[:, None] // PRESHUFFLE_TILE) * (PRESHUFFLE_TILE * 128)
                    + (offs_d[None, :] // PRESHUFFLE_TILE) * (PRESHUFFLE_TILE * PRESHUFFLE_TILE)
                    + (pos_in_page[:, None] % PRESHUFFLE_TILE) * PRESHUFFLE_TILE
                    + offs_d[None, :] % PRESHUFFLE_TILE)
            else:
                kv_offsets = page_base[:, None] + pos_in_page[:, None] * 128 + offs_d[None, :]
            kv_u8_vals = tl.load(kvcache_u8 + kv_offsets, mask=valid_s[:, None], other=0)
            kv_vals = kv_u8_vals.to(FP8_TY, bitcast=True).to(DOT_TY)

            h_mask = offs_h < num_heads
            q_u8_vals = tl.load(
                q_u8
                + bid * q_stride_b
                + offs_h[:, None] * q_stride_h
                + offs_d[None, :] * q_stride_d,
                mask=h_mask[:, None],
                other=0,
            )
            q_vals = q_u8_vals.to(FP8_TY, bitcast=True).to(DOT_TY)

            scores = tl.dot(kv_vals, tl.trans(q_vals)).to(tl.float32)
            w = tl.load(
                weights + bid * weights_stride_b + offs_h * weights_stride_h,
                mask=h_mask,
                other=0.0,
            ).to(tl.float32)
            reduced = tl.sum(tl.maximum(scores, 0.0) * w[None, :], axis=1)

            scale_offset = page_base + 8192 + pos_in_page * 4
            s0 = tl.load(kvcache_u8 + scale_offset + 0, mask=valid_s, other=0).to(tl.uint32)
            s1 = tl.load(kvcache_u8 + scale_offset + 1, mask=valid_s, other=0).to(tl.uint32)
            s2 = tl.load(kvcache_u8 + scale_offset + 2, mask=valid_s, other=0).to(tl.uint32)
            s3 = tl.load(kvcache_u8 + scale_offset + 3, mask=valid_s, other=0).to(tl.uint32)
            scale_bits = s0 | (s1 << 8) | (s2 << 16) | (s3 << 24)
            scale = scale_bits.to(tl.float32, bitcast=True)

            result = tl.where(valid_s, reduced * scale, 0.0)
            tl.store(
                out + bid * out_stride_b + offs_s * out_stride_s,
                result,
                mask=offs_s < max_seq_len,
            )
        else:
            # Keep defined scratch, but never load Q/K or score trivial rows.
            tl.store(out + bid * out_stride_b + offs_s * out_stride_s,
                     0.0, mask=offs_s < max_seq_len)


    @triton.jit
    def _fp8_paged_mqa_logits_nonempty_kernel(
        q_u8, kvcache_u8, weights, seq_lens, page_table, out,
        max_num_pages: tl.constexpr, max_seq_len: tl.constexpr,
        num_heads: tl.constexpr,
        q_stride_b: tl.constexpr, q_stride_h: tl.constexpr, q_stride_d: tl.constexpr,
        kv_stride_page: tl.constexpr,
        weights_stride_b: tl.constexpr, weights_stride_h: tl.constexpr,
        page_table_stride_b: tl.constexpr, page_table_stride_p: tl.constexpr,
        out_stride_b: tl.constexpr, out_stride_s: tl.constexpr,
        FP8_TY: tl.constexpr, DOT_TY: tl.constexpr, PRESHUFFLE_TILE: tl.constexpr,
        BLOCK_S: tl.constexpr, BLOCK_H: tl.constexpr, BLOCK_D: tl.constexpr,
        TRIVIAL_TOPK: tl.constexpr,
    ):
        # Graph width is capacity, not live KV length. Empty tiles used to
        # execute the FP8 conversion and MFMA against masked zero K values.
        # Preserve all stores and use the original arithmetic on live tiles.
        row = tl.program_id(0)
        tile = tl.program_id(1)
        length = tl.load(seq_lens + row)
        if tile * BLOCK_S < length:
            _fp8_paged_mqa_logits_kernel(
                q_u8, kvcache_u8, weights, seq_lens, page_table, out,
                max_num_pages, max_seq_len, num_heads,
                q_stride_b, q_stride_h, q_stride_d, kv_stride_page,
                weights_stride_b, weights_stride_h,
                page_table_stride_b, page_table_stride_p, out_stride_b, out_stride_s,
                FP8_TY, DOT_TY, PRESHUFFLE_TILE, BLOCK_S, BLOCK_H, BLOCK_D, TRIVIAL_TOPK,
            )
        else:
            columns = tile * BLOCK_S + tl.arange(0, BLOCK_S)
            tl.store(out + row * out_stride_b + columns * out_stride_s,
                     0.0, mask=columns < max_seq_len)


def _fp8_paged_mqa_logits_triton(
    q_fp8: torch.Tensor,
    kvcache_fp8: torch.Tensor,
    weight: torch.Tensor,
    seq_lens: torch.Tensor,
    page_table: torch.Tensor,
    max_seq_len: int,
    skip_trivial_topk: int = 0,
    *,
    skip_empty_tiles: bool = False,
) -> Optional[torch.Tensor]:
    if triton is None:
        _debug_fp8_paged_mqa_logits_skip("triton is unavailable")
        return None
    if not envs.SGLANG_OPT_USE_TRITON_INDEXER_FULL.get():
        _debug_fp8_paged_mqa_logits_skip("SGLANG_OPT_USE_TRITON_INDEXER_FULL is off")
        return None
    if not is_hip():
        _debug_fp8_paged_mqa_logits_skip("not HIP")
        return None
    if (
        q_fp8.dim() != 4
        or kvcache_fp8.dim() != 4
        or weight.dim() != 2
        or page_table.dim() != 2
    ):
        _debug_fp8_paged_mqa_logits_skip(
            "rank mismatch: "
            f"q={tuple(q_fp8.shape)} kv={tuple(kvcache_fp8.shape)} "
            f"weight={tuple(weight.shape)} page_table={tuple(page_table.shape)}"
        )
        return None

    batch_size, _, num_heads, head_dim = q_fp8.shape
    block_size = kvcache_fp8.shape[1]
    if (
        q_fp8.shape[1] != 1
        or head_dim != 128
        or block_size != 64
        or kvcache_fp8.shape[2:] != (1, head_dim + 4)
        or weight.shape != (batch_size, num_heads)
        or page_table.shape[0] != batch_size
        or q_fp8.stride(-1) != 1
    ):
        _debug_fp8_paged_mqa_logits_skip(
            "shape/stride mismatch: "
            f"q_shape={tuple(q_fp8.shape)} q_stride={q_fp8.stride()} "
            f"kv_shape={tuple(kvcache_fp8.shape)} kv_stride={kvcache_fp8.stride()} "
            f"weight_shape={tuple(weight.shape)} page_table_shape={tuple(page_table.shape)}"
        )
        return None

    if seq_lens.dim() > 1:
        seq_lens = seq_lens.squeeze(-1)
    if seq_lens.shape != (batch_size,):
        _debug_fp8_paged_mqa_logits_skip(
            f"seq_lens mismatch: shape={tuple(seq_lens.shape)} batch_size={batch_size}"
        )
        return None
    seq_lens = seq_lens.to(torch.int32)

    q_u8 = q_fp8.view(torch.uint8)
    kvcache_u8 = kvcache_fp8.view(-1, block_size * (head_dim + 4)).view(torch.uint8)
    out = torch.empty(
        (batch_size, max_seq_len), dtype=torch.float32, device=q_fp8.device
    )

    block_s = envs.SGLANG_DSV4_GFX90A_INDEXER_BLOCK_S.get()
    if block_s not in (16, 32, 64, 128):
        raise ValueError(
            "SGLANG_DSV4_GFX90A_INDEXER_BLOCK_S must be one of 16, 32, 64, 128; "
            f"got {block_s}"
        )
    block_h = triton.next_power_of_2(num_heads)
    if block_h > 64:
        _debug_fp8_paged_mqa_logits_skip(
            f"too many heads for current kernel: num_heads={num_heads}"
        )
        return None
    fp8_ty = tl.float8e4b8 if is_fp8_fnuz() else tl.float8e4nv
    dot_ty = (
        tl.float16
        if envs.SGLANG_DSV4_GFX90A_INDEXER_FP16_DOT.get()
        else tl.bfloat16
    )
    grid = (batch_size, triton.cdiv(max_seq_len, block_s))
    global _c4_trivial_logits_debug_logged
    if (
        skip_trivial_topk
        and not _c4_trivial_logits_debug_logged
        and os.getenv("SGLANG_DSV4_INDEXER_DEBUG", "0") == "1"
    ):
        print(
            f"[DSV4 indexer] trivial logits skip active: rows={batch_size}, "
            f"C4_width={max_seq_len}, topk={skip_trivial_topk}",
            flush=True,
        )
        _c4_trivial_logits_debug_logged = True
    kernel = (
        _fp8_paged_mqa_logits_nonempty_kernel
        if skip_empty_tiles else _fp8_paged_mqa_logits_kernel
    )
    global _c4_empty_tiles_debug_logged
    if skip_empty_tiles and not _c4_empty_tiles_debug_logged:
        print(
            f"[DSV4 indexer] empty-tile kernel selected: rows={batch_size}, "
            f"C4_capacity={max_seq_len}, BLOCK_S={block_s}; no KV truncation",
            flush=True,
        )
        _c4_empty_tiles_debug_logged = True
    kernel[grid](
        q_u8,
        kvcache_u8,
        weight,
        seq_lens,
        page_table,
        out,
        page_table.shape[1],
        max_seq_len,
        num_heads,
        q_u8.stride(0),
        q_u8.stride(2),
        q_u8.stride(3),
        kvcache_u8.stride(0),
        weight.stride(0),
        weight.stride(1),
        page_table.stride(0),
        page_table.stride(1),
        out.stride(0),
        out.stride(1),
        FP8_TY=fp8_ty,
        DOT_TY=dot_ty,
        PRESHUFFLE_TILE=(INDEXER_K_CACHE_PRESHUFFLE_TILE
                        if aiter_can_use_preshuffle_paged_mqa() else 0),
        BLOCK_S=block_s,
        BLOCK_H=block_h,
        BLOCK_D=128,
        TRIVIAL_TOPK=skip_trivial_topk,
    )
    return out


def _fp8_mqa_logits_post_triton(
    scores: torch.Tensor,
    weights: torch.Tensor,
    kv_scales: torch.Tensor,
    seq_lens: torch.Tensor,
    max_seq_len: int,
) -> Optional[torch.Tensor]:
    if (
        triton is None
        or not envs.SGLANG_OPT_USE_TRITON_INDEXER_POST.get()
        or not is_hip()
        or scores.dim() != 3
        or weights.dim() != 2
        or kv_scales.dim() != 2
    ):
        return None

    batch_size, padded_seq_len, num_heads = scores.shape
    if (
        weights.shape != (batch_size, num_heads)
        or kv_scales.shape[0] != batch_size
        or kv_scales.shape[1] < padded_seq_len
    ):
        return None

    if seq_lens.dim() > 1:
        seq_lens = seq_lens.squeeze(-1)
    seq_lens = seq_lens.to(torch.int32)
    out = torch.empty(
        (batch_size, max_seq_len), dtype=torch.float32, device=scores.device
    )
    block_s = 16
    block_h = triton.next_power_of_2(num_heads)
    grid = (batch_size, triton.cdiv(max_seq_len, block_s))
    _fp8_mqa_logits_post_kernel[grid](
        scores,
        weights,
        kv_scales,
        seq_lens,
        out,
        padded_seq_len,
        max_seq_len,
        num_heads,
        scores.stride(0),
        scores.stride(1),
        scores.stride(2),
        weights.stride(0),
        weights.stride(1),
        kv_scales.stride(0),
        kv_scales.stride(1),
        out.stride(0),
        out.stride(1),
        BLOCK_S=block_s,
        BLOCK_H=block_h,
    )
    return out


def fp8_paged_mqa_logits_torch(
    q_fp8: torch.Tensor,
    kvcache_fp8: torch.Tensor,
    weight: torch.Tensor,
    seq_lens: torch.Tensor,
    page_table: torch.Tensor,
    deep_gemm_metadata: Any,
    max_seq_len: int,
    clean_logits: bool = True,
    *,
    skip_trivial_topk: int = 0,
    skip_empty_tiles: bool = False,
) -> torch.Tensor:
    """Graph-compatible logits; optional Top-K-only trivial rows become zero.

    skip_trivial_topk is opt-in: those scores are not meaningful, and the
    consumer must synthesize all valid IDs without consulting scores.
    skip_empty_tiles preserves every output score, including zero tail values.
    """
    _ = deep_gemm_metadata
    batch_size, _, num_heads, head_dim = q_fp8.shape
    block_size = kvcache_fp8.shape[1]

    assert head_dim == 128
    assert block_size == 64
    assert q_fp8.shape == (batch_size, 1, num_heads, head_dim)
    assert kvcache_fp8.shape[1:] == (block_size, 1, head_dim + 4)
    assert weight.shape == (batch_size, num_heads)
    assert seq_lens.shape == (batch_size,)
    assert page_table.shape[0] == batch_size
    assert clean_logits == False
    if skip_trivial_topk not in (0, 512):
        raise ValueError("skip_trivial_topk must be 0 or 512")

    max_num_pages = page_table.shape[1]
    triton_scores = _fp8_paged_mqa_logits_triton(
        q_fp8, kvcache_fp8, weight, seq_lens, page_table, max_seq_len,
        skip_trivial_topk=skip_trivial_topk,
        skip_empty_tiles=skip_empty_tiles,
    )
    if triton_scores is not None:
        return triton_scores

    SCALE_OFFSET = block_size * head_dim
    total_dim = block_size * (head_dim + 4)

    kvcache_flat = kvcache_fp8.view(-1, total_dim)

    pages_clamped = page_table.clamp(min=0)
    kvcache_gathered = kvcache_flat[pages_clamped]

    kv_values_raw = kvcache_gathered[..., :SCALE_OFFSET].contiguous()
    kv_values_fp8 = kv_values_raw.view(dtype=FP8_DTYPE)
    kv_values = kv_values_fp8.to(torch.bfloat16)
    if aiter_can_use_preshuffle_paged_mqa():
        tile = INDEXER_K_CACHE_PRESHUFFLE_TILE
        kv_values = kv_values.reshape(
            batch_size, max_num_pages, block_size // tile,
            head_dim // tile, tile, tile,
        ).permute(0, 1, 2, 4, 3, 5).contiguous()
    kv_values = kv_values.reshape(batch_size, max_num_pages * block_size, head_dim)

    kv_scales_raw = kvcache_gathered[..., SCALE_OFFSET:].contiguous()
    kv_scales = kv_scales_raw.view(dtype=torch.float32)
    kv_scales = kv_scales.reshape(batch_size, max_num_pages * block_size)

    q_float = q_fp8[:, 0].to(torch.bfloat16)
    scores = torch.bmm(kv_values, q_float.transpose(1, 2))
    padded_seq_len = max_num_pages * block_size
    fused_scores = _fp8_mqa_logits_post_triton(
        scores, weight, kv_scales, seq_lens, max_seq_len
    )
    if fused_scores is not None:
        return fused_scores

    scores = F.relu(scores)
    scores = scores * weight.unsqueeze(1)
    scores = scores.sum(dim=2)
    scores = scores * kv_scales

    cache = _arange_cache
    arange_key = f"arange_{padded_seq_len}_{scores.device}"
    if arange_key not in cache:
        cache[arange_key] = torch.arange(padded_seq_len, device=scores.device)
    positions = cache[arange_key].unsqueeze(0)
    valid_mask = positions < seq_lens.unsqueeze(1)
    scores = scores.masked_fill(~valid_mask, 0.0)

    if padded_seq_len < max_seq_len:
        scores = F.pad(scores, (0, max_seq_len - padded_seq_len), value=0.0)
    else:
        scores = scores[:, :max_seq_len]

    return scores


def _aiter_fp8_paged_mqa_logits(
    q_fp8: torch.Tensor,
    kvcache_fp8: torch.Tensor,
    weight: torch.Tensor,
    seq_lens: torch.Tensor,
    page_table: torch.Tensor,
    deep_gemm_metadata: Any,
    max_seq_len: int,
    clean_logits: bool = False,
) -> torch.Tensor:
    """Wrapper adapting aiter's deepgemm_fp8_paged_mqa_logits to SGLang's interface."""
    from aiter.ops.triton.attention.pa_mqa_logits import (
        deepgemm_fp8_paged_mqa_logits,
    )

    batch_size = q_fp8.shape[0]
    next_n = q_fp8.shape[1]
    total_tokens = batch_size * next_n
    _sl = seq_lens.squeeze(-1) if seq_lens.dim() == 2 else seq_lens
    kv_block_size = kvcache_fp8.shape[1]
    logits = torch.empty(
        total_tokens,
        max_seq_len,
        dtype=torch.float32,
        device=q_fp8.device,
    )
    deepgemm_fp8_paged_mqa_logits(
        q_fp8,
        kvcache_fp8,
        weight,
        logits,
        _sl.to(torch.int32),
        page_table.to(torch.int32),
        max_seq_len,
        KVBlockSize=kv_block_size,
        Preshuffle=aiter_can_use_preshuffle_paged_mqa(),
    )
    return logits


def fp8_paged_mqa_logits_torch_sm120(
    q_fp8: torch.Tensor,
    kvcache_fp8: torch.Tensor,
    weight: torch.Tensor,
    seq_lens: torch.Tensor,
    page_table: torch.Tensor,
    deep_gemm_metadata: Any,
    max_seq_len: int,
    clean_logits: bool = True,
) -> torch.Tensor:
    """CUDA-graph-compatible FP8 paged MQA logits for SM120 (vectorized, no .item())."""
    _ = deep_gemm_metadata
    batch_size, _, num_heads, head_dim = q_fp8.shape
    block_size = kvcache_fp8.shape[1]
    device = q_fp8.device

    _QUERY_CHUNK = 1024
    if batch_size > _QUERY_CHUNK:
        return torch.cat(
            [
                fp8_paged_mqa_logits_torch_sm120(
                    q_fp8[start : start + _QUERY_CHUNK],
                    kvcache_fp8,
                    weight[start : start + _QUERY_CHUNK],
                    seq_lens[start : start + _QUERY_CHUNK],
                    page_table[start : start + _QUERY_CHUNK],
                    deep_gemm_metadata,
                    max_seq_len,
                    clean_logits=clean_logits,
                )
                for start in range(0, batch_size, _QUERY_CHUNK)
            ],
            dim=0,
        )

    assert head_dim == 128, "Vectorized torch impl hardcodes DSV4 indexer head_dim=128"
    assert (
        block_size == 64
    ), "Vectorized torch impl hardcodes block_size=64 cache layout"
    assert q_fp8.shape == (batch_size, 1, num_heads, head_dim)
    assert kvcache_fp8.shape[1:] == (block_size, 1, head_dim + 4)
    assert weight.shape == (batch_size, num_heads)
    if seq_lens.dim() > 1:
        seq_lens = seq_lens.squeeze(-1)
    assert seq_lens.shape == (batch_size,)
    assert page_table.shape[0] == batch_size
    assert clean_logits == False

    max_pages = (max_seq_len + block_size - 1) // block_size
    max_padded_seq = max_pages * block_size

    kvcache_flat = kvcache_fp8.view(-1, block_size * (head_dim + 4))
    SCALE_OFFSET = block_size * head_dim

    page_ids = page_table[:, :max_pages]
    kvcache_gathered = kvcache_flat[page_ids]

    kv_value_raw = kvcache_gathered[..., :SCALE_OFFSET]
    kv_scale_raw = kvcache_gathered[..., SCALE_OFFSET:]

    kv_value = kv_value_raw.contiguous().view(dtype=FP8_DTYPE).to(torch.bfloat16)
    kv_value = kv_value.view(batch_size, max_padded_seq, head_dim)

    kv_scale = kv_scale_raw.contiguous().view(dtype=torch.float32)
    kv_scale = kv_scale.view(batch_size, max_padded_seq)

    q = q_fp8[:, 0].to(torch.bfloat16)

    score = torch.bmm(kv_value, q.transpose(1, 2))

    score = F.relu(score)
    score = score * weight.unsqueeze(1)
    score = score.sum(dim=2)

    score = score * kv_scale

    out_width = min(max_padded_seq, max_seq_len)
    logits = score.new_full((batch_size, max_seq_len), float("-inf"))
    logits[:, :out_width] = score[:, :out_width]

    positions = torch.arange(max_seq_len, device=device)
    invalid_mask = positions.unsqueeze(0) >= seq_lens.unsqueeze(1)
    logits.masked_fill_(invalid_mask, float("-inf"))

    return logits


def _topk_transform_512_vectorized(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    out_raw_indices: Optional[torch.Tensor] = None,
    topk_op: Callable[..., Tuple[torch.Tensor, torch.Tensor]] = torch.topk,
    topk_op_kwargs: Optional[Dict[str, object]] = None,
    contiguous_topk_input: bool = False,
) -> None:
    TOPK = out_page_indices.shape[1]
    batch_size = scores.shape[0]
    max_seq_len = scores.shape[1]
    device = scores.device

    page_bits = (page_size - 1).bit_length() if page_size > 1 else 0
    page_mask = page_size - 1

    cache = _arange_cache
    key_seq = f"arange_{max_seq_len}_{device}"
    key_topk = f"arange_{TOPK}_{device}"
    key_bs = f"arange_{batch_size}_{device}"
    if key_seq not in cache:
        cache[key_seq] = torch.arange(max_seq_len, device=device)
    if key_topk not in cache:
        cache[key_topk] = torch.arange(TOPK, device=device, dtype=torch.int32)
    if key_bs not in cache:
        cache[key_bs] = torch.arange(batch_size, device=device)

    positions = cache[key_seq].unsqueeze(0).expand(batch_size, -1)
    valid_mask = positions < seq_lens.unsqueeze(1)

    masked_scores = scores.clone()
    masked_scores.masked_fill_(~valid_mask, float("-inf"))

    actual_k = min(TOPK, max_seq_len)
    topk_kwargs = (
        {"dim": 1, "largest": True, "sorted": False}
        if topk_op_kwargs is None
        else topk_op_kwargs
    )
    topk_input = masked_scores.contiguous() if contiguous_topk_input else masked_scores
    _, raw_indices = topk_op(topk_input, actual_k, **topk_kwargs)
    raw_indices = raw_indices.to(torch.int32)

    if actual_k < TOPK:
        raw_indices = F.pad(raw_indices, (0, TOPK - actual_k), value=0)

    batch_indices = cache[key_bs].unsqueeze(1).expand(-1, TOPK)
    gathered_scores = scores[
        batch_indices.flatten(), raw_indices.clamp(min=0).flatten()
    ].view(batch_size, TOPK)

    valid_topk = gathered_scores != float("-inf")
    if actual_k < TOPK:
        pad_mask = cache[key_topk].unsqueeze(0) >= actual_k
        valid_topk = valid_topk & ~pad_mask

    needs_sequential = seq_lens <= TOPK
    sequential_indices = cache[key_topk].unsqueeze(0).expand(batch_size, -1)
    sequential_valid = sequential_indices < seq_lens.unsqueeze(1)

    seq_indices_or_neg1 = sequential_indices.clone()
    seq_indices_or_neg1.masked_fill_(~sequential_valid, -1)

    needs_seq_mask = needs_sequential.unsqueeze(1).expand(-1, TOPK)
    raw_indices = torch.where(needs_seq_mask, seq_indices_or_neg1, raw_indices)
    valid_topk = torch.where(needs_seq_mask, sequential_valid, valid_topk)

    page_idx = raw_indices >> page_bits
    offset_in_page = raw_indices & page_mask

    page_idx_clamped = torch.clamp(page_idx, min=0)
    physical_pages = torch.gather(page_tables, dim=1, index=page_idx_clamped.long())

    page_indices = (physical_pages << page_bits) | offset_in_page
    page_indices = page_indices.to(torch.int32)
    page_indices.masked_fill_(~valid_topk, -1)

    out_page_indices.copy_(page_indices)

    if out_raw_indices is not None:
        raw_indices = raw_indices.clone()
        raw_indices.masked_fill_(~valid_topk, -1)
        out_raw_indices.copy_(raw_indices)


def topk_transform_512_pytorch_vectorized(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    out_raw_indices: Optional[torch.Tensor] = None,
) -> None:
    """Vectorized PyTorch fallback for topk_transform_512.
    All helper tensors (arange, zeros) are cached to avoid device-tensor
    creation during HIP/CUDA graph capture."""

    _topk_transform_512_vectorized(
        scores,
        seq_lens,
        page_tables,
        out_page_indices,
        page_size,
        out_raw_indices,
        topk_op=torch.topk,
        topk_op_kwargs={"dim": 1, "largest": True, "sorted": False},
    )


def topk_transform_512_flashinfer_unfused(
    scores: torch.Tensor,
    seq_lens: torch.Tensor,
    page_tables: torch.Tensor,
    out_page_indices: torch.Tensor,
    page_size: int,
    out_raw_indices: Optional[torch.Tensor] = None,
) -> None:
    import flashinfer

    from sglang.srt.layers.attention.dsa.dsa_topk_backend import (
        _flashinfer_tie_break_value,
    )

    _topk_transform_512_vectorized(
        scores,
        seq_lens,
        page_tables,
        out_page_indices,
        page_size,
        out_raw_indices,
        topk_op=flashinfer.top_k,
        topk_op_kwargs={
            "sorted": False,
            "deterministic": envs.SGLANG_DSA_TOPK_FLASHINFER_DETERMINISTIC.get(),
            "tie_break": _flashinfer_tie_break_value(),
            "dsa_graph_safe": True,
        },
        contiguous_topk_input=True,
    )


class C4IndexerBackendMixin:
    def __init__(self):
        super().__init__()
        self.debug_use_external_c4_sparse_indices: bool = False
        self.dsa_topk_backend: DSATopKBackend = DSATopKBackend.SGL_KERNEL

    def _use_c4_empty_decode_tiles(self, forward_batch: "ForwardBatch") -> bool:
        # Opt-in original-V4 native AR only. Keep prefill, DSpark, MTP draft
        # and paged V4.1 execution unchanged; unknown backend roles fail closed.
        return (
            envs.SGLANG_DSV4_GFX90A_AR_INDEXER_EMPTY_TILE_SKIP.get()
            and is_hip()
            and is_gfx90a_supported()
            and forward_batch.forward_mode == ForwardMode.DECODE
            and bool(getattr(self.token_to_kv_pool, "_unified_kv", False))
            and getattr(self, "is_draft_worker", True) is False
            and getattr(self, "is_dspark_target", True) is False
            and getattr(self, "mtp_enabled", True) is False
        )

    def _use_c4_empty_prefill_tiles(self, forward_batch, c4_indexer) -> bool:
        # Separate from the accepted AR selector: ordinary original-V4 prefill
        # only. Keep causal lengths, compressor writes and canonical Top-K.
        return (
            os.getenv("SGLANG_DSV4_C4_PREFILL_EMPTY_TILE_SKIP", "0") == "1"
            and is_hip()
            and is_gfx90a_supported()
            and forward_batch.forward_mode == ForwardMode.EXTEND
            and bool(getattr(c4_indexer.compressor, "_debug_original_v4", False))
            and bool(getattr(self.token_to_kv_pool, "_unified_kv", False))
            and getattr(self, "is_draft_worker", True) is False
            and getattr(self, "is_dspark_target", True) is False
            and getattr(self, "mtp_enabled", True) is False
            and self.dsa_topk_backend.is_sgl_kernel()
            and c4_indexer.index_topk == 512
            and os.getenv("SGLANG_DSV4_GFX90A_CANONICAL_INDEXER_ORDER", "3") in ("2", "3")
        )

    def _use_c4_prefill_query_reuse(self, forward_batch, c4_indexer, rows) -> bool:
        if not (
            os.getenv("SGLANG_DSV4_C4_PREFILL_QUERY_REUSE4", "0") == "1"
            and os.getenv("SGLANG_DSV4_C4_TRIVIAL_LOGITS_SKIP", "0") == "1"
            and self._use_c4_empty_prefill_tiles(forward_batch, c4_indexer)
            and 8192 <= rows <= 65536
            and getattr(forward_batch, "tbo_parent_token_range", None) is None
            and getattr(forward_batch, "_original_forward_mode", None) is None
        ):
            return False
        ps = get_parallel()
        return (
            ps.tp_size == ps.attn_tp_size == 8
            and ps.moe_ep_size == ps.attn_cp_size == ps.pp_size == 1
            and not torch.cuda.is_current_stream_capturing()
        )

    @staticmethod
    def _should_skip_c4_indexer_logits(
        c4_indexer: "C4Indexer",
        forward_batch: "ForwardBatch",
    ) -> bool:
        # For kv_len <= index_topk, top-k selects every valid C4 token. The
        # paged MQA logits are then unnecessary; a dummy score matrix fed to the
        # existing topk_transform produces the same page-slot indices.
        fb = forward_batch
        # index_topk is expressed in C4-cache rows, while ForwardBatch
        # seq_lens are full-resolution token positions.  Comparing the latter
        # directly to 512 enabled the expensive sparse-indexer graph four
        # times too early (at raw position 512, where only ~128 C4 rows exist
        # and Top-512 necessarily selects all of them).
        raw_skip_limit = c4_indexer.index_topk * int(
            getattr(c4_indexer.compressor, "ratio", 4)
        )
        if fb.forward_mode.is_extend_without_speculative():
            if fb.seq_lens_cpu is None or fb.seq_lens_cpu.numel() == 0:
                return False
            return int(fb.seq_lens_cpu.max().item()) <= raw_skip_limit

        if not (
            fb.forward_mode.is_decode_or_idle()
            or fb.forward_mode.is_target_verify()
        ):
            return False
        if not is_hip():
            return False

        from sglang.srt.model_executor.runner_utils.capture_mode import (
            get_capture_dsa_variant,
            get_is_capture_mode,
        )

        if get_is_capture_mode():
            variant = get_capture_dsa_variant()
            if variant == "dense":
                return True
            if variant == "sparse":
                return False
            return False

        if fb.seq_lens_cpu is not None and fb.seq_lens_cpu.numel() > 0:
            max_kv_len = int(fb.seq_lens_cpu.max().item())
        elif fb.seq_lens is not None and fb.seq_lens.numel() > 0:
            max_kv_len = int(fb.seq_lens.max().item())
        else:
            return False
        return max_kv_len <= raw_skip_limit

    def _forward_prepare_multi_stream(
        self,
        x: torch.Tensor,
        q_lora: torch.Tensor,
        c4_indexer: C4Indexer,
        positions: torch.Tensor,
        forward_batch: ForwardBatch,
        alt_streams: Optional[List[torch.cuda.Stream]] = None,
        q_lora_ready: Optional[torch.cuda.Event] = None,
    ) -> Tuple[IndexerQuery, torch.Tensor]:
        if TYPE_CHECKING:
            assert isinstance(self, CompressorBackendMixin)

        assert alt_streams is not None
        assert len(alt_streams) >= 2
        current_stream = torch.cuda.current_stream()
        stream_q = alt_streams[0]
        stream_weights = alt_streams[1]

        stream_q.wait_stream(current_stream)
        stream_weights.wait_stream(current_stream)

        self.forward_indexer_compressor(
            x=x,
            forward_batch=forward_batch,
            layer_id=c4_indexer.layer_id,
            compressor=c4_indexer.compressor,
        )

        # The weight projection is small and fast; compute it on its own
        # stream, then have the Q stream wait on it before launching the big
        # fused Q kernel (which folds rope, hadamard, quantization, and
        # weight scaling into one pass).
        with torch.cuda.stream(stream_weights):
            weights = c4_indexer.compute_weights(x, skip_scale=True)
            weights_ready = stream_weights.record_event()

        with torch.cuda.stream(stream_q):
            if q_lora_ready is not None:
                stream_q.wait_event(q_lora_ready)
            stream_q.wait_event(weights_ready)
            q, weights = c4_indexer.compute_q(q_lora, positions, weights)

        current_stream.wait_stream(stream_q)
        return q, weights

    def _forward_prepare_normal(
        self,
        x: torch.Tensor,
        q_lora: torch.Tensor,
        c4_indexer: C4Indexer,
        positions: torch.Tensor,
        forward_batch: ForwardBatch,
        skip_compressor: bool = False,
    ) -> Tuple[IndexerQuery, torch.Tensor]:
        if TYPE_CHECKING:
            assert isinstance(self, CompressorBackendMixin)

        if _prefill_detail_mark is not None:
            _prefill_detail_mark(49, f"indexer_query_rows_{x.shape[0]}", absolute=True)
        precomputed = getattr(forward_batch, "_dsv4_precomputed_index_weights", None)
        weights = (
            precomputed.pop(c4_indexer.layer_id)
            if precomputed is not None and c4_indexer.layer_id in precomputed
            else c4_indexer.compute_weights(x, skip_scale=True)
        )
        if _prefill_detail_mark is not None:
            _prefill_detail_mark(50, "indexer_weights_done", absolute=True)
        q, weights = c4_indexer.compute_q(q_lora, positions, weights)
        if _prefill_detail_mark is not None:
            _prefill_detail_mark(51, "indexer_query_done", absolute=True)
        if not skip_compressor:
            self.forward_indexer_compressor(
                x=x,
                forward_batch=forward_batch,
                layer_id=c4_indexer.layer_id,
                compressor=c4_indexer.compressor,
            )
        if _prefill_detail_mark is not None:
            _prefill_detail_mark(52, "indexer_compressor_done", absolute=True)
        return q, weights

    def _can_use_nonpaged_indexer(
        self,
        *,
        c4_indexer: C4Indexer,
        forward_batch: ForwardBatch,
        indexer_metadata: PagedIndexerMetadata,
    ) -> bool:
        if not envs.SGLANG_OPT_DSV4_NONPAGED_INDEXER.get():
            return False
        # This path calls CUDA DeepGEMM and assumes the CUDA FP8+FP32 packed
        # indexer cache layout. Explicitly reject HIP, NPU, and other devices.
        if not is_cuda() or is_hip():
            return False
        # The gather plan is built from eager, child-local ForwardBatch metadata.
        # Rewritten, TBO-split, and graph-backed batches must use the paged path.
        if (
            forward_batch.forward_mode != ForwardMode.EXTEND
            or forward_batch._original_forward_mode is not None
            or forward_batch.tbo_parent_token_range is not None
            or forward_batch.batch_size != 1
            or indexer_metadata.use_prefill_cuda_graph
        ):
            return False
        if (
            c4_indexer.use_fp4_indexer
            or envs.SGLANG_OPT_USE_TILELANG_INDEXER.get()
            or envs.SGLANG_OPT_USE_AITER_INDEXER.get()
            or envs.SGLANG_FP8_PAGED_MQA_LOGITS_TORCH.get()
        ):
            return False
        if (
            get_parallel().attn_cp_size != 1
            or self.hisparse_coordinator is not None
            or is_in_tc_piecewise_cuda_graph()
            or is_in_breakable_cuda_graph()
        ):
            return False
        return not torch.cuda.is_current_stream_capturing()

    def _get_nonpaged_indexer_plan(
        self,
        *,
        c4_indexer: C4Indexer,
        forward_batch: ForwardBatch,
        indexer_metadata: PagedIndexerMetadata,
        page_table: torch.Tensor,
        c4_seq_lens: torch.Tensor,
        query_rows: int,
    ) -> Optional[NonPagedIndexerPlan]:
        if query_rows < envs.SGLANG_OPT_DSV4_NONPAGED_INDEXER_MIN_QUERY_TOKENS.get():
            return None
        if not self._can_use_nonpaged_indexer(
            c4_indexer=c4_indexer,
            forward_batch=forward_batch,
            indexer_metadata=indexer_metadata,
        ):
            return None
        if indexer_metadata.nonpaged_plan is not None:
            return indexer_metadata.nonpaged_plan

        if (
            forward_batch.seq_lens is None
            or forward_batch.seq_lens_cpu is None
            or forward_batch.extend_seq_lens_cpu is None
            or forward_batch.extend_seq_lens is None
            or forward_batch.extend_start_loc is None
            or forward_batch.extend_num_tokens is None
        ):
            return None

        def to_cpu_int_list(values) -> Optional[List[int]]:
            if isinstance(values, torch.Tensor):
                if values.device.type != "cpu":
                    return None
                values = values.tolist()
            return [int(value) for value in values]

        extend_lens_cpu = to_cpu_int_list(forward_batch.extend_seq_lens_cpu)
        seq_lens_cpu = to_cpu_int_list(forward_batch.seq_lens_cpu)
        if (
            extend_lens_cpu is None
            or seq_lens_cpu is None
            or len(extend_lens_cpu) != 1
            or len(seq_lens_cpu) != 1
            or extend_lens_cpu[0] <= 0
        ):
            return None

        actual_queries = extend_lens_cpu[0]
        if (
            actual_queries != query_rows
            or int(forward_batch.extend_num_tokens) != query_rows
            or forward_batch.seq_lens.numel() != 1
            or forward_batch.extend_seq_lens.numel() != 1
            or forward_batch.extend_start_loc.numel() != 1
            or page_table.dim() != 2
            or page_table.shape[0] < query_rows
            or c4_seq_lens.numel() < query_rows
        ):
            return None

        final_c4_len = seq_lens_cpu[0] // 4
        if final_c4_len <= 0:
            return None

        request_page_table = page_table[:1].contiguous()
        ke = c4_seq_lens[:query_rows].reshape(-1).to(torch.int32).contiguous()
        gather_seq_lens = ke[-1:]
        ks = torch.zeros_like(ke)
        # SGL Top-K synthesizes sequential indices for trivial rows without
        # reading logits, so DeepGEMM can receive an empty range for them.
        if self.dsa_topk_backend.is_sgl_kernel():
            ke = torch.where(ke - ks > c4_indexer.index_topk, ke, ks)
        c4_page_size = indexer_metadata.c4_page_size
        max_seqlen_k = (final_c4_len + c4_page_size - 1) // c4_page_size * c4_page_size
        plan = NonPagedIndexerPlan(
            page_table=request_page_table,
            gather_seq_lens=gather_seq_lens,
            ks=ks,
            ke=ke,
            seq_len_sum=final_c4_len,
            max_seq_len=final_c4_len,
            max_seqlen_k=max_seqlen_k,
            query_rows=query_rows,
        )
        indexer_metadata.nonpaged_plan = plan
        return plan

    @staticmethod
    def _forward_nonpaged_indexer(
        *,
        q_indexer: torch.Tensor,
        weights: torch.Tensor,
        c4_indexer: C4Indexer,
        token_to_kv_pool: DeepSeekV4TokenToKVPool,
        plan: NonPagedIndexerPlan,
    ) -> torch.Tensor:
        import deep_gemm

        k_u8, scale_u8 = token_to_kv_pool.get_index_k_scale_buffer(
            layer_id=c4_indexer.layer_id,
            seq_len_tensor=plan.gather_seq_lens,
            page_indices=plan.page_table,
            seq_len_sum=plan.seq_len_sum,
            max_seq_len=plan.max_seq_len,
        )
        k_fp8 = k_u8.view(FP8_DTYPE)
        k_scale = scale_u8.view(torch.float32).squeeze(-1)
        return deep_gemm.fp8_mqa_logits(
            q_indexer[: plan.query_rows],
            (k_fp8, k_scale),
            weights[: plan.query_rows],
            plan.ks,
            plan.ke,
            clean_logits=False,
            max_seqlen_k=plan.max_seqlen_k,
        )

    def forward_c4_indexer(
        self,
        x: torch.Tensor,
        q_lora: torch.Tensor,
        c4_indexer: C4Indexer,
        forward_batch: ForwardBatch,
        alt_streams: Optional[List[torch.cuda.Stream]] = None,
        enable_multi_stream: bool = False,
        q_lora_ready: Optional[torch.cuda.Event] = None,
        skip_compressor: bool = False,
    ) -> None:
        if forward_batch.forward_mode.is_idle():
            return
        if _prefill_detail_mark is not None:
            _prefill_detail_mark(48, "forward_c4_indexer", absolute=True)
        token_to_kv_pool = self.token_to_kv_pool

        if TYPE_CHECKING:
            assert isinstance(token_to_kv_pool, DeepSeekV4TokenToKVPool)
            assert isinstance(self, CompressorBackendMixin)

        metadata = self.forward_metadata
        indexer_metadata = metadata.indexer_metadata
        core_metadata = metadata.core_metadata

        assert isinstance(indexer_metadata, PagedIndexerMetadata)

        positions = core_metadata.positions
        num_queries = min(x.shape[0], q_lora.shape[0], positions.shape[0])
        if x.shape[0] != num_queries:
            x = x[:num_queries]
        if q_lora.shape[0] != num_queries:
            q_lora = q_lora[:num_queries]
        if positions.shape[0] != num_queries:
            positions = positions[:num_queries]

        use_fp4_indexer = c4_indexer.use_fp4_indexer
        skip_logits_computation = self._should_skip_c4_indexer_logits(
            c4_indexer, forward_batch
        )
        if skip_logits_computation:
            if not skip_compressor:
                self.forward_indexer_compressor(
                    x=x,
                    forward_batch=forward_batch,
                    layer_id=c4_indexer.layer_id,
                    compressor=c4_indexer.compressor,
                )
            query_rows = num_queries
            logits = torch.zeros(
                (query_rows, c4_indexer.index_topk),
                dtype=torch.float32,
                device=x.device,
            )
        else:
            if enable_multi_stream:
                q_indexer, weights = self._forward_prepare_multi_stream(
                    x=x,
                    q_lora=q_lora,
                    c4_indexer=c4_indexer,
                    positions=positions,
                    forward_batch=forward_batch,
                    alt_streams=alt_streams,
                    q_lora_ready=q_lora_ready,
                )
            else:
                assert q_lora_ready is None
                q_indexer, weights = self._forward_prepare_normal(
                    x=x,
                    q_lora=q_lora,
                    c4_indexer=c4_indexer,
                    positions=positions,
                    forward_batch=forward_batch,
                    skip_compressor=skip_compressor,
                )

            if use_fp4_indexer:
                q_fp4, q_sf = q_indexer
                assert len(q_fp4.shape) == 3
                assert len(q_sf.shape) == 2
                q = (q_fp4.unsqueeze(1), q_sf.unsqueeze(1))
            else:
                assert len(q_indexer.shape) == 3
                q = q_indexer.unsqueeze(1)

            assert len(weights.shape) == 3
            weights = weights.squeeze(2)
            if use_fp4_indexer:
                weights = weights.float()
                if envs.SGLANG_OPT_USE_TILELANG_INDEXER.get():
                    raise RuntimeError(
                        "DeepSeek V4 FP4 indexer requires DeepGEMM indexer."
                    )
                from deep_gemm import fp8_fp4_paged_mqa_logits as fn
            elif envs.SGLANG_OPT_USE_TILELANG_INDEXER.get():
                from sglang.kernels.ops.attention.dsa.tilelang_kernel import (
                    tilelang_fp8_paged_mqa_logits as fn,
                )
            elif envs.SGLANG_OPT_USE_AITER_INDEXER.get():
                fn = _aiter_fp8_paged_mqa_logits
            elif envs.SGLANG_FP8_PAGED_MQA_LOGITS_TORCH.get() or (
                is_hip() and envs.SGLANG_OPT_USE_TRITON_INDEXER_FULL.get()
            ):
                if is_sm120_supported():
                    fn = fp8_paged_mqa_logits_torch_sm120
                else:
                    fn = fp8_paged_mqa_logits_torch
            elif is_xpu():
                from sgl_kernel import fp8_paged_mqa_logits_triton

                # TODO: switch from triton to SYCL when OOM is resolved

                fn = fp8_paged_mqa_logits_triton
            else:
                from deep_gemm import fp8_paged_mqa_logits as fn

            query_rows = (
                q_indexer[0].shape[0] if use_fp4_indexer else q_indexer.shape[0]
            )

        def match_num_queries(tensor: torch.Tensor, value: int) -> torch.Tensor:
            if tensor.shape[0] == query_rows:
                return tensor
            if tensor.shape[0] > query_rows:
                return tensor[:query_rows]
            pad = (0, 0) * (tensor.dim() - 1) + (0, query_rows - tensor.shape[0])
            return F.pad(tensor, pad, value=value)

        c4_seq_lens = match_num_queries(indexer_metadata.c4_seq_lens, value=1)
        _c4sl = c4_seq_lens
        page_table = match_num_queries(indexer_metadata.page_table, value=0)
        c4_sparse_page_indices = match_num_queries(
            core_metadata.c4_sparse_page_indices, value=-1
        )
        _use_tilelang = (
            envs.SGLANG_OPT_USE_TILELANG_INDEXER.get() and not use_fp4_indexer
        )
        _use_aiter = envs.SGLANG_OPT_USE_AITER_INDEXER.get() and not use_fp4_indexer
        if _c4sl.dim() == 1 and not _use_tilelang and not _use_aiter:
            _c4sl = _c4sl.unsqueeze(-1)
        if not skip_logits_computation:
            nonpaged_plan = self._get_nonpaged_indexer_plan(
                c4_indexer=c4_indexer,
                forward_batch=forward_batch,
                indexer_metadata=indexer_metadata,
                page_table=page_table,
                c4_seq_lens=c4_seq_lens,
                query_rows=query_rows,
            )
            if nonpaged_plan is not None:
                assert isinstance(q_indexer, torch.Tensor)
                logits = self._forward_nonpaged_indexer(
                    q_indexer=q_indexer,
                    weights=weights,
                    c4_indexer=c4_indexer,
                    token_to_kv_pool=token_to_kv_pool,
                    plan=nonpaged_plan,
                )
            else:
                c4_indexer_kv_cache = token_to_kv_pool.get_index_k_with_scale_buffer(
                    layer_id=c4_indexer.layer_id,
                )
                assert c4_indexer_kv_cache.dim() == 2
                head_dim_with_sf = 68 if use_fp4_indexer else 132
                if not _use_tilelang and not _use_aiter and _c4sl.dim() == 2:
                    _c4sl = _c4sl.squeeze(-1)
                c4_indexer_kv_cache = c4_indexer_kv_cache.view(
                    c4_indexer_kv_cache.shape[0], 64, 1, head_dim_with_sf
                )
                # Experimental prefill-only optimization. Do not change live
                # lengths or compressor/cache updates: later queries need keys
                # produced by rows whose own selection is currently trivial.
                logits_kwargs = {}
                if (
                    fn is fp8_paged_mqa_logits_torch
                    and is_hip()
                    and is_gfx90a_supported()
                    and forward_batch.forward_mode == ForwardMode.EXTEND
                    and self.dsa_topk_backend.is_sgl_kernel()
                    and c4_indexer.index_topk == 512
                    and os.getenv("SGLANG_DSV4_C4_TRIVIAL_LOGITS_SKIP", "0") == "1"
                    and os.getenv("SGLANG_DSV4_GFX90A_CANONICAL_INDEXER_ORDER", "3") in ("2", "3")
                ):
                    logits_kwargs["skip_trivial_topk"] = c4_indexer.index_topk
                if (
                    fn is fp8_paged_mqa_logits_torch
                    and self._use_c4_empty_decode_tiles(forward_batch)
                ):
                    logits_kwargs["skip_empty_tiles"] = True
                if (
                    fn is fp8_paged_mqa_logits_torch
                    and self._use_c4_empty_prefill_tiles(forward_batch, c4_indexer)
                ):
                    logits_kwargs["skip_empty_tiles"] = True
                    global _c4_empty_prefill_debug_logged
                    if not _c4_empty_prefill_debug_logged:
                        print(
                            f"[DSV4 indexer] prefill empty tiles selected: rows={q.shape[0]} "
                            f"C4_capacity={indexer_metadata.max_c4_seq_len} "
                            f"BLOCK_S={envs.SGLANG_DSV4_GFX90A_INDEXER_BLOCK_S.get()}",
                            flush=True,
                        )
                        _c4_empty_prefill_debug_logged = True
                logits = None
                if (
                    fn is fp8_paged_mqa_logits_torch
                    and self._use_c4_prefill_query_reuse(forward_batch, c4_indexer, q.shape[0])
                ):
                    from sglang.kernels.ops.attention.dsv4.gfx90a_indexer_query_reuse import prefill_query_reuse4

                    query_group_size = int(os.getenv("SGLANG_DSV4_C4_PREFILL_QUERY_GROUP_SIZE", "4"))
                    runtime_m = (query_group_size == 16 and
                                 os.getenv("SGLANG_DSV4_C4_PREFILL_QUERY_RUNTIME_M", "0") == "1")
                    logits = prefill_query_reuse4(
                        q, c4_indexer_kv_cache, weights, _c4sl, page_table,
                        indexer_metadata.max_c4_seq_len,
                        block_s=envs.SGLANG_DSV4_GFX90A_INDEXER_BLOCK_S.get(),
                        preshuffle_tile=(INDEXER_K_CACHE_PRESHUFFLE_TILE
                            if aiter_can_use_preshuffle_paged_mqa() else 0),
                        dot_fp16=envs.SGLANG_DSV4_GFX90A_INDEXER_FP16_DOT.get(),
                        fp8_fnuz=is_fp8_fnuz(),
                        query_group_size=query_group_size,
                        runtime_m=runtime_m,
                        allow_wide=os.getenv("SGLANG_DSV4_C4_PREFILL_QUERY_WIDE", "0") == "1",
                        trace_rank=(get_parallel().tp_rank if
                            os.getenv("SGLANG_DSV4_DEBUG_INDEXER_COMPILE_SHAPES", "0") == "1" else None),
                    )
                    global _c4_query_reuse_debug_logged
                    if logits is not None and not _c4_query_reuse_debug_logged:
                        print(f"[TP{get_parallel().tp_rank}] [DSV4 indexer] prefill query-reuse4 selected: rows={q.shape[0]} "
                              f"C4_capacity={indexer_metadata.max_c4_seq_len} query_group={query_group_size} "
                              f"runtime_m={int(runtime_m)}", flush=True)
                        _c4_query_reuse_debug_logged = True
                    global _c4_query_wide_debug_logged
                    if logits is not None and indexer_metadata.max_c4_seq_len > 2048 and not _c4_query_wide_debug_logged:
                        print(f"[TP{get_parallel().tp_rank}] [DSV4 indexer] prefill wide-query-reuse selected: rows={q.shape[0]} "
                              f"C4_capacity={indexer_metadata.max_c4_seq_len} query_group={query_group_size} "
                              f"runtime_m={int(runtime_m)}", flush=True)
                        _c4_query_wide_debug_logged = True
                if logits is None:
                    logits = fn(
                        q,
                        c4_indexer_kv_cache,
                        weights,
                        _c4sl,
                        page_table,
                        indexer_metadata.deep_gemm_metadata,
                        indexer_metadata.max_c4_seq_len,
                        False,
                        **logits_kwargs,
                    )

        if _prefill_detail_mark is not None:
            _prefill_detail_mark(53, "indexer_logits_done", absolute=True)
        assert indexer_metadata.page_table is core_metadata.page_table
        if self.debug_use_external_c4_sparse_indices:
            return

        indexer_capturer = get_global_indexer_capturer()
        capture_enabled = indexer_capturer is not None

        hisparse_coordinator = self.hisparse_coordinator
        hisparse_decode = (
            hisparse_coordinator is not None and forward_batch.forward_mode.is_decode()
        )

        raw_indices = None
        if capture_enabled:
            raw_indices = torch.empty_like(c4_sparse_page_indices)
        elif hisparse_decode:
            raw_indices = hisparse_coordinator.raw_indices_buffer[
                : c4_sparse_page_indices.size(0)
            ]
        elif core_metadata.c4_sparse_raw_indices is not None:
            raw_indices = core_metadata.c4_sparse_raw_indices

        if self.dsa_topk_backend.is_torch():
            topk_transform_512_pytorch_vectorized(
                logits,
                c4_seq_lens,
                page_table,
                c4_sparse_page_indices,
                indexer_metadata.c4_page_size,
                raw_indices,
            )
        elif self.dsa_topk_backend.is_flashinfer():
            topk_transform_512_flashinfer_unfused(
                logits,
                c4_seq_lens,
                page_table,
                c4_sparse_page_indices,
                indexer_metadata.c4_page_size,
                raw_indices,
            )
        elif envs.SGLANG_OPT_USE_TOPK_V2.get() and raw_indices is None:
            topk_transform_512_v2(
                logits,
                c4_seq_lens,
                page_table,
                c4_sparse_page_indices,
                indexer_metadata.c4_page_size,
                indexer_metadata.topk_metadata,
            )
        else:
            topk_transform_512(
                logits,
                c4_seq_lens,
                page_table,
                c4_sparse_page_indices,
                indexer_metadata.c4_page_size,
                raw_indices,
            )
        if _prefill_detail_mark is not None:
            _prefill_detail_mark(54, "indexer_topk_done", absolute=True)
        if hisparse_coordinator is not None:
            if hisparse_decode:
                compress_layer_id = token_to_kv_pool.layer_mapping[
                    c4_indexer.layer_id
                ].compress_layer_id
                core_metadata.c4_sparse_page_indices = (
                    hisparse_coordinator.swap_in_selected_pages(
                        req_pool_indices=forward_batch.req_pool_indices,
                        compressed_seq_lens=indexer_metadata.c4_seq_lens,
                        top_k_result=raw_indices,
                        layer_id=compress_layer_id,
                    )
                )
            else:
                # flash_mla C4 attention requires int32 page indices.
                core_metadata.c4_sparse_page_indices = (
                    token_to_kv_pool.c4_kv_pool.translate_loc_to_hisparse_device(
                        core_metadata.c4_sparse_page_indices
                    ).to(torch.int32)
                )

        if capture_enabled:
            compress_layer_id = token_to_kv_pool.layer_mapping[
                c4_indexer.layer_id
            ].compress_layer_id
            indexer_capturer.capture(compress_layer_id, raw_indices)


class C4Indexer(nn.Module):
    def __init__(
        self,
        config: DeepSeekV4Config,
        layer_id: int,
        freqs_cis: torch.Tensor,
        quant_config: Optional[QuantizationConfig] = None,
        prefix: str = "",
        alt_streams: Optional[List[torch.cuda.Stream]] = None,
        rotary_emb=None,
    ):
        super().__init__()
        self.layer_id = layer_id
        self.dim = config.hidden_size
        self.n_heads = config.index_n_heads
        self.head_dim = config.index_head_dim
        self.rope_head_dim = config.qk_rope_head_dim
        self.index_topk = config.index_topk
        self.q_lora_rank = config.q_lora_rank
        self.softmax_scale = self.head_dim**-0.5
        self.n_local_heads = self.n_heads
        self.wq_b = ReplicatedLinear(
            self.q_lora_rank,
            self.n_heads * self.head_dim,
            bias=False,
            quant_config=quant_config,
            params_dtype=torch.bfloat16,
            prefix=add_prefix("wq_b", prefix),
        )
        expert_pack_quant_config = (
            quant_config
            if quant_config is not None and quant_config.get_name() == "expert_pack"
            else None
        )
        self.weights_proj = ReplicatedLinear(
            self.dim,
            self.n_heads,
            bias=False,
            quant_config=expert_pack_quant_config,
            params_dtype=torch.bfloat16,
            prefix=add_prefix("weights_proj", prefix),
        )
        # The full C4 indexer turns on abruptly once KV length exceeds
        # index_topk.  Its replicated 1024->8192 query projection otherwise
        # stays on the generic block-FP8 small-M path on gfx90a, which is much
        # slower than the BF16 decode GEMM and caused the observed throughput
        # cliff at absolute position 512.  Reuse the existing attention BF16
        # cache policy for both indexer-only projections; the short-context
        # skip graph remains unchanged.
        if (
            is_gfx90a_supported()
            and envs.SGLANG_DSV4_GFX90A_BF16_ATTN_LINEAR.get()
        ):
            self.wq_b._cache_block_fp8_weight_as_bf16 = True
            self.weights_proj._cache_block_fp8_weight_as_bf16 = True
        self.compressor = Compressor(
            config,
            self.layer_id,
            True,
            freqs_cis,
            compress_ratio=4,
            head_dim=self.head_dim,
            rotate=True,
            prefix=add_prefix("compressor", prefix),
            quant_config=expert_pack_quant_config,
            rotary_emb=rotary_emb,
        )
        self.rotary_emb = rotary_emb
        self.freqs_cis = freqs_cis
        self.weight_scale: float = self.softmax_scale * self.n_heads**-0.5

        self.use_fp4_indexer = get_exec().kernel.enable_deepseek_v4_fp4_indexer
        self.alt_streams = alt_streams

    def compute_q(
        self,
        q_lora: torch.Tensor,
        positions: torch.Tensor,
        weight: torch.Tensor,
    ) -> Tuple[IndexerQuery, torch.Tensor]:
        q, _ = self.wq_b(q_lora)
        q = q.view(-1, self.n_local_heads, self.head_dim)
        if self.use_fp4_indexer:
            return fused_q_indexer_rope_hadamard_fp4_quant(
                q.contiguous(), weight, self.weight_scale, self.freqs_cis, positions
            )
        return fused_q_indexer_rope_hadamard_quant(
            q, weight, self.weight_scale, self.freqs_cis, positions
        )

    def compute_weights(self, x: torch.Tensor, skip_scale=False) -> torch.Tensor:
        out, _ = self.weights_proj(x)
        if not skip_scale:
            out = out * self.weight_scale
        return out

    def forward(
        self,
        x: torch.Tensor,
        q_lora: torch.Tensor,
        forward_batch: ForwardBatch,
        attn_backend: AttentionBackend,
        enable_multi_stream: bool = False,
        q_lora_ready: Optional[torch.cuda.Event] = None,
        skip_compressor: bool = False,
    ) -> None:
        return attn_backend.forward_c4_indexer(
            x=x,
            q_lora=q_lora,
            forward_batch=forward_batch,
            c4_indexer=self,
            alt_streams=self.alt_streams,
            enable_multi_stream=enable_multi_stream,
            q_lora_ready=q_lora_ready,
            skip_compressor=skip_compressor,
        )
